import {  createContext, useState} from "react";



const TodoContext = createContext();

 export const TodoProvider = ({children})=>{
    
    // State
const [todos , setTodos] = useState([{id : 1 , text : "My Context Todo"}]);


const [edit , setEdit] = useState({ todo :  {},    isEdit : false, });

// DeleteTodo


const deleteTodo = (id)=> {setTodos(todos.filter((todo) => todo.id !== id ));
};

// SaveTodo

const saveTodo = (text)=>{
 const newTodo = {
    id : crypto.randomUUID(),
    text,
 };

 setTodos([newTodo, ...todos]);
};

// Edit Todo

  const editTodo =(todo )=>{
    setEdit({todo:todo , isEdit : true}); 
  };
 

//   // Star Todo

//   const completeTodo =(id )=>{
// setTodos(todos.filter((todo) => todo.id !== id ));


//   };
 

//   Update Todo
const updateTodo = (id , text)=>{
    setTodos(todos.map(item=> item.id === id ? {...item , text: text } : item) );
    setEdit({todo:{}, isEdit :false});
}  

    return(
        <TodoContext.Provider value={{todos,edit , deleteTodo , saveTodo, editTodo, updateTodo , completeTodo }}>{children}</TodoContext.Provider>
    );
};

export default TodoContext;

